/****************************************************************
 * 功能说明：登录功能业务逻辑处理
 * 创  建  人：李兴东
 * 创建日期：2015-03-17
 ***********
 * 修改日期      修改人      修改内容
 * ----------    --------    ------------------------------------
 *
 *
 ****************************************************************/

mui.init();

var prelHomeWV;
var txtMsg = new YTHTextMsg();
var userNameElem = document.getElementById("pmlUserName");
var userPassElem = document.getElementById("pmlUserPass");

//预加载首页
mui.plusReady(function() {
//放到登录碾轼里加载
});

//登录
document.getElementById('pmlGoLogin').addEventListener('tap', function() {
             		
	//验证输入
	if (!userNameElem.value.TrimSpace()) {
		mui.toast('请输入账号');
		return;
	}
	
	//登录验证
	var param = {
		"UserName": userNameElem.value.TrimSpace(),
		"Password": userPassElem.value.TrimSpace(),
		"DeviceId": YTHConstValue.APPDeviceId
	};
	var fparam = (new YTHFormatSerParam()).Format(param, false);
	var loginWaiting = null;
	mui.ajax((new YTHServiceUrl()).GetSUCommon() + "JOYOJCheckUserInfo", {
		type: 'post', timeout: 10000, crossDomain: true,
		contentType: 'text/json', data: fparam,
		dataType: 'text',
		beforeSend: function(xhr) {
			loginWaiting = plus.nativeUI.showWaiting("登录验证中...");
		},
		success: function(data, ts, xhr) {
			var jdata = JSON.parse(JSON.parse(data));
			if(jdata.Status.Success) {
				//持久化状态并转场
				(new YTHUserContext()).SetUserContext({
					"UserName": userNameElem.value.TrimSpace(),
					"Token": jdata.Result.Token || "",
					"AutoLogin": document.getElementById("pmlSaveStatus").checked
				});
				
			    prelHomeWV = mui.preload({
		            url: "/storage/emulated/0/Android/data/io.dcloud.HBuilder/.HBuilder/apps/HBuilder/page/pmain/hello.html",
		            id: "pmain-hometab",
		            styles: { scrollIndicator: "none" }
	            });
	            
				prelHomeWV.show("pop-in", 100);	
			} else {
				mui.toast(txtMsg.GetServicesError(jdata.Status.Message));
			}
		},
		complete: function(xhr, ts) {
			loginWaiting.close();
		},
        error: function(xhr, ts, et) {
        	mui.toast(txtMsg.GetSendError(ts, et));
        }
	});
	
});

//使用说明
document.getElementById('pmlGoGuide').addEventListener('tap', function() {
	var preguide = new YTHOpenWindow("../putil/guide.html", "putil-guide");
	preguide.OpenInSubMasDefPre(1, "使用说明", "gear");
});

//返回键，1秒内，连续两次按返回键，退出应用
var bqa = new YTHBackQuitApp();
mui.back = function() {
	bqa.QuitApp();
};